1. 安装node

2. 安装依赖

```
npm install
```

3. 开发阶段

```
npm run dev
```

4. 上线阶段

```
npm run prod
```