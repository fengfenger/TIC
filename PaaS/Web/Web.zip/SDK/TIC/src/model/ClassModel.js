function ClassModel() {
  this.compatSaas = false; // 是否要与Saas互通
}

export default ClassModel;